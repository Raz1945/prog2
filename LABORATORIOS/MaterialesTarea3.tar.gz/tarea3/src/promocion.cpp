#include "../include/promocion.h"

//  La estructura almacena un id de tipo entero, dos fechas para representar el inicio y el fin 
// de la promocion, así como la información de qué productos forman parte de la promocion.
struct rep_promocion {

};

TPromocion crearTPromocion(int idProm, TFecha ini, TFecha fin, int cantMax){ return NULL; }

void agregarATPromocion(TPromocion &prom, TProducto p){}

void imprimirTPromocion(TPromocion prom){}

void liberarTPromocion(TPromocion &prom){}

bool perteneceATPromocion(TPromocion prom, TProducto p){ return false; }

int idTPromocion(TPromocion prom){ return 0; }

TFecha fechaInicioTPromocion(TPromocion prom){ return NULL; }

TFecha fechaFinTPromocion(TPromocion prom){ return NULL; }

bool sonPromocionesCompatibles(TPromocion prom1, TPromocion prom2){ return false; }



