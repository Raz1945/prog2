#include "../include/cliente.h"

struct rep_cliente {
    
};


TCliente crearTCliente(int id, const char nombre[MAX_NOMBRE], const char apellido[MAX_APELLIDO], int edad){
    return NULL;
}

void imprimirTCliente(TCliente cliente){

}

void liberarTCliente(TCliente &cliente){

}

void nombreTCliente(TCliente cliente, char nombre[MAX_NOMBRE]){

}

void apellidoTCliente(TCliente cliente, char apellido[MAX_APELLIDO]){

}

int idTCliente(TCliente cliente){
    return 0;
}

int edadTCliente(TCliente cliente){
    return 0;
}

TCliente copiarTCliente(TCliente cliente){
    return NULL;
}
