#include "../include/clientesSucursalesLDE.h"

struct rep_clientesSucursalesLDE {

};


TClientesSucursalesLDE crearTClientesSucursalesLDEVacia(){
	return NULL;
}

void insertarClientesABBTClientesSucursalesLDE(TClientesSucursalesLDE clientesSucursalesLDE, TClientesABB clientesABB, int idSucursal){

}

void liberarTClientesSucursalesLDE(TClientesSucursalesLDE &clientesSucursalesLDE){

}

void imprimirTClientesSucursalesLDE(TClientesSucursalesLDE clientesSucursalesLDE){

}

void imprimirInvertidoTClientesSucursalesLDE(TClientesSucursalesLDE clientesSucursalesLDE){

}

nat cantidadTClientesABBClientesSucursalesLDE(TClientesSucursalesLDE clientesSucursalesLDE){
	return 0;
}

TClientesABB obtenerPrimeroClientesSucursalesLDE(TClientesSucursalesLDE clientesSucursalesLDE){
	return NULL;
}

TClientesABB obtenerNesimoClientesSucursalesLDE(TClientesSucursalesLDE clientesSucursalesLDE, int n){
	return NULL;
}

TClientesABB removerUltimoClientesSucursalesLDE(TClientesSucursalesLDE clientesSucursalesLDE){
	return NULL;
}

TClientesABB removerNesimoClientesSucursalesLDE(TClientesSucursalesLDE clientesSucursalesLDE, int n){
	return NULL;
}

TCliente clienteMasRepetido(TClientesSucursalesLDE clientesSucursalesLDE){
	return NULL;
}
