#include "../include/producto.h"

struct rep_producto {

};


TProducto crearTProducto(int id, const char nombre[MAX_NOMBRE_PRODUCTO], int precio, TFecha fechaIngreso){
    return NULL;
}

int idTProducto(TProducto producto){
    return 0;
}

int precioTProducto(TProducto producto){
    return 0;
}

void imprimirTProducto(TProducto producto){

}

void liberarTProducto(TProducto &producto){

}


