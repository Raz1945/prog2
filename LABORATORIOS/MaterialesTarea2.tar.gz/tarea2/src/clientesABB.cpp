#include "../include/clientesABB.h"

struct rep_clientesABB {
    
};


TClientesABB crearTClientesABBVacio(){
    return NULL;
}

void insertarTClienteTClientesABB(TClientesABB &clientesABB, TCliente cliente){

}

void imprimirTClientesABB(TClientesABB clientesABB){

}

void liberarTClientesABB(TClientesABB &clientesABB){

}

bool existeTClienteTClientesABB(TClientesABB clientesABB, int idCliente){
    return false;
}

TCliente obtenerTClienteTClientesABB(TClientesABB clientesABB, int idCliente){
    return NULL;
}

nat alturaTClientesABB(TClientesABB clientesABB){
    return 0;
}

TCliente maxIdTClienteTClientesABB(TClientesABB clientesABB){
    return NULL;
}

void removerTClienteTClientesABB(TClientesABB &clientesABB, int idCliente){

}

int cantidadClientesTClientesABB(TClientesABB clientesABB){
    return 0;
}

float edadPromedioTClientesABB(TClientesABB clientesABB){
    return 0.;
}

TCliente obtenerNesimoClienteTClientesABB(TClientesABB clientesABB, int n){
    return NULL;
}

