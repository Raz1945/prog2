#include "../include/carritoProductos.h"

struct rep_carritoProductos{
    
};


TCarritoProductos crearCarritoProductosVacio(){
    return NULL;
}

void insertarProductoCarritoProductos(TCarritoProductos &carritoProductos, TProducto producto){

}

void imprimirCarritoProductos(TCarritoProductos carritoProductos){

}

void liberarCarritoProductos(TCarritoProductos &carritoProductos){

}

bool esVacioCarritoProductos(TCarritoProductos carritoProductos){
    return true;
}

bool existeProductoCarritoProductos(TCarritoProductos carritoProductos, int idProducto){
    return true;
}

TProducto obtenerProductoCarritoProductos(TCarritoProductos carritoProductos, int idProducto){
    return NULL;
}

void removerProductoCarritoProductos(TCarritoProductos &carritoProductos, int idProducto){

}