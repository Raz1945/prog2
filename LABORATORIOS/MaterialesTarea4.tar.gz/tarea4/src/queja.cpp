#include "../include/queja.h"

struct rep_queja { };

TQueja crearTQueja(TFecha fecha, TProducto producto, TCliente cliente,
                   const char comentario[MAX_COMENTARIO]) {
  return NULL;
}

void imprimirTQueja(TQueja queja) { }

void liberarTQueja(TQueja &queja) { }

TFecha fechaTQueja(TQueja queja) { return NULL; }
