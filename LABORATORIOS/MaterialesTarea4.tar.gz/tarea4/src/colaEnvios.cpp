#include "../include/colaEnvios.h"

struct rep_cola_envios {
};

TColaEnvios crearTColaEnvios(int N) { 
    return NULL;
 }

void encolarEnvioTColaEnvios(TColaEnvios &colaEnvios, TEnvio envio) {
    
}

int cantidadTColaEnvios(TColaEnvios colaEnvios) { return 0; }

void imprimirTColaEnvios(TColaEnvios colaEnvios) {
}

TEnvio desencolarTColaEnvios(TColaEnvios &colaEnvios) { 
    return NULL;

 }

void liberarTColaEnvios(TColaEnvios &colaEnvios) {
  
}

void invertirPrioridadTColaEnvios(TColaEnvios &colaEnvio) {
  
}

TEnvio masPrioritarioTColaEnvios(TColaEnvios colaEnvio) { return NULL; }

int maxTColaEnvios(TColaEnvios colaEnvio) { return 0; }