#include "../include/envio.h"

struct rep_envio {
};

TEnvio crearTEnvio(TCarritoProductos carrito, TFecha fecha) {
  return NULL;
}

void liberarTEnvio(TEnvio &envio) {}

TCarritoProductos obtenerCarritoProductosTEnvio(TEnvio envio) { return NULL; }

TFecha obtenerFechaTEnvio(TEnvio envio) { return NULL; }

void imprimirTEnvio(TEnvio envio) {
}
